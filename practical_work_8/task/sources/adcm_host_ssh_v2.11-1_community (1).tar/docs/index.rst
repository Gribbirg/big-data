.. Arenadata documentation master file, created by
   sphinx-quickstart on Tue Apr 13 15:25:38 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

SSH Common Provider
==========================

SSH Common Provider предназначен для выполнения оперций над виртуальными машинами, используя SSH соединение.

Описание установки и настройки кластер-менеджера ADCM приведено на странице: `Документация ADCM <https://docs.arenadata.io/adcm/index.html>`_.

.. important:: Контактная информация службы поддержки -- e-mail: info@arenadata.io

.. toctree::
   :maxdepth: 2
   :caption: Оглавление:

   ../Config/index
   ../Add_host/index
   ../Actions/index
   ../Host_actions/index
