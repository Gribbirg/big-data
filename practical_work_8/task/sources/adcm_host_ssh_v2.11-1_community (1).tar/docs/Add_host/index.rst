Добавление Host
===============

Добавить хост можно, перейдя во вкладку *HOSTS*. После нажатия кнопки *Create host* неободимо заполнить следующие поля (:numref:`Рис.%s.<ssh_add_host1>`).

.. _ssh_add_host1:

.. figure:: ../imgs/ssh_add_host1.png
   :align: center

   Добавление хоста

После нажатия кнопки *Save*, необходимо перейти во вкладку *Configuration*, появившейся виртуальной машины, и заполнить все небходимые поля (:numref:`Рис.%s.<ssh_add_host2>`):

.. _ssh_add_host2:

.. figure:: ../imgs/ssh_add_host2.png
   :align: center

   Поля, необходимые для заполнения

+ *Username* -- username, используемый для подключения к ВМ по SSH;
+ *Password* -- пароль для подключения к ВМ по SSH;
+ *SSH private key* -- приватный SSH ключ;
+ *Hostname* -- IP адрес ВМ для подключения;
+ *Port* -- SSH порт;
+ *SSH args* -- SSH аргументы для Ansible;
+ *Ansible become* -- выдача привилегий суперпользователя;
+ *Ansible become password* -- пароль для выдачи привилегий суперпользователя.

После установки statuschecker, во вкладке *Main* будет отображаться необходимая для ssh подключения информация (:numref:`Рис.%s.<ssh_add_host3>`):

.. _ssh_add_host3:

.. figure:: ../imgs/ssh_add_host3.png
   :align: center

   Информация для ssh подключения
