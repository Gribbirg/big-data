Настройка SSH Common Provider
=============================

В разделе *Configuration* существует блок Metadata, для создания хостов, необоходимо произвести настройку провайдера.
Указать порт подключения, имя пользователя, пароль, ssh_private.key и ssh_public.key для создания пользователей.
В разделе Advanced возможно указать параметры подключения к хосту, такие как, Ansible become, Ansible become password, SSH args.
:doc:`../Actions/index`.
