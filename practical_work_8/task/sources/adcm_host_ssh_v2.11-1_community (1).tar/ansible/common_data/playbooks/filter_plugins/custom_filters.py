'''Custom ansible filters for dicts'''


class FilterModule():
    """Class for ansible to access to custom filters"""

    def filters(self):
        """Interface method to ansible"""

        return {
            'to_users': self.to_users
        }

    @staticmethod
    def to_users(admin_ssh_keys, groups=None):
        """converts a list of admin ssh keys to a list of users"""
        return [{
            'login': key.split(' ')[2].split('@')[0],
            'groups': groups,
            'ssh_key': key,
            'pwless_sudo': True
        } for key in admin_ssh_keys]
