# Changelog
## 01.10.18
* Add "token" param 
* Redirect output to /dev/null
## 27.03.20
* Add new checker_type=docker and scripts for adcm-docker-status-checker
