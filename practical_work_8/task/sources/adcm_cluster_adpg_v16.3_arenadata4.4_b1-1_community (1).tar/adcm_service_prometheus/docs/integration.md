# ADMProm integration with products

![Bundle](images/bundle.png)

Monitoring service manages Prometheus based environment to collect product's metrics.

![Monitoring](images/monitoring.png)

## Common exporters

Monitoring service configures and manages node-exporter and push-gateway exporters for all product.

### node-exporter

`node-exporter` service collects and exports the system metrics of the host on which it is installed.

### push-gateway

`push-gateway` is an optional component and could be excluded from the bundle. It stores and exports metrics in the following cases:

- Store and exports metrics of short-living jobs.
- Handle specific-metrics from ADCM configuration. ADQM stores the cluster topology in push-gateway, for example.
- etc.

It's required to define `admprom_enable_pushgateway` variable with `True` value in `admprom/macros.yml.j2` file.

### admprom_repos_role
`admprom_repos_role` is an optional flag that used to run repos via different roles:

- If you want that ADMPROM repos should be installed automatically by role adcm_job_repo than leave as default (adcm_job_repo)
- If you want to setup ADMPROM repos by yourself set as false and use adcm_role_repos value

### admprom_fail_on_check
`admprom_fail_on_check` is an optional flag that used in order to change check components logic:

- If you want to fail on first failing check of ADMPROM components, leave as default (true)
- If you want to ignore fail errors on check, set up false

## Product exporters

All specific product's metrics could be scratched from:

- Functional services export Prometheus format metrics with endpoint.
- Standalone services collecting metrics from Product services and sharing them with endpoint.

These standalone services have to be implemented as the component of Monitoring service. All their configuration can be stored both in Monitoring service's configuration or in the component's configuration.

Configuration of functional services to share metrics have to be stored in the corresponding service or component's configuration with its main configuration. 

### Product-specific settings in Monitoring service's configuration

```yaml
- type: service
  name: prometheus_monitoring
  display_name: Monitoring
  version: &monitoring_version 1.0.0

  config:

    {{ admprom_product_specific_settings() | indent(4) }}
```

Monitoring service allow to append product-specific exporters settings. They could be exporter's ports, endpoints, etc.

### Product-specific components in Monitoring service

```yaml
- type: service
  name: prometheus_monitoring
  display_name: Monitoring
  version: &monitoring_version 1.0.0

  components:
    prometheus:
    grafana:
    pushgateway:
    node_exporter:

    {{ admprom_product_specific_components() | indent(6) }}
```

`admprom_product_specific_components` macro includes all required components with their settings and actions.

## Actions integration

### Products cluster actions

#### Install\Reinstall

```yaml
scripts:
  - task: Install the cluster                 # Install and configure product specific services
                                              # Install and configure product specific exporters

  {{ admprom_cluster_action_install() }}      # Install Monitoring services
                                              # Prometheus, Grafana, push-gateway (optional), node-exporter
```

`admprom_cluster_action_install` macro do the following:

```yaml
{% macro admprom_cluster_action_install() -%}
  - task: Install Monitoring services         # Prometheus, Grafana, push-gateway (optional), node-exporter

  {{ admprom_install_product_exporters }}     # Install product-specific standalone exporters
  {{ admprom_post_service_install }}          # Product-specific actions. For example, update of the cluster's exports
{%- endmacro -%}

```

#### Check

```yaml
scripts:
  - task: Check the cluster                   # Check product specific services
                                              # Check product specific exporters

  {{ admprom_cluster_action_check() }}        # Install Monitoring services
                                              # Prometheus, Grafana, push-gateway (optional), node-exporter
```

`admprom_cluster_action_check` macro do the following:

```yaml
{% macro admprom_cluster_action_check() -%}
  - task: Check Monitoring services           # Prometheus, Grafana, push-gateway (optional), node-exporter

  {{ admprom_check_product_exporters }}       # Check product specific exporters
{%- endmacro -%}
```

#### Upgrade

```yaml
scripts:
  - task: Upgrade the cluster                 # Upgrade product specific services
                                              # Upgrade product specific exporters

  {{ admprom_cluster_action_upgrade() }}        # Install Monitoring services
                                              # Prometheus, Grafana, push-gateway (optional), node-exporter
```

`admprom_cluster_action_upgrade` macro do the following:

```yaml
{% macro admprom_cluster_action_upgrade() -%}
  - task: Upgrade Monitoring services           # Prometheus, Grafana, push-gateway (optional), node-exporter

  {{ admprom_upgrdae_product_exporters }}       # Upgrade product specific exporters
  {{ admprom_post_service_upgrade }}            # Product-specific actions. For example, update of the cluster's exports
{%- endmacro -%}
```

#### Expand\Shrink

The cluster or product-specific service may have `Expand` and `Shrink` actions. If these action adds or remove product-specific metrics exporters than these actions have to call `admprom_expand_targets` or `admprom_shrink_targets`.

Example of Expand action:
```yaml
scripts:
  - task: Install service on additional hosts         # Install product specific services
                                                      # Install product specific exporters

  {{ admprom_expand_targets() }}                      # Reconfigure Monitoring services
```

`admprom_expand_targets` requires group of hosts the service\cluster is expanded on and do the following:

```yaml
{% macro admprom_expand_targets() -%}
- task: Reconfigure Monitoring services               # Update prometheus targets, push-gateway metrics (optional)
{%- endmacro -%}
```

`admprom_shrink_targets` macro do the following:

```yaml
{% macro admprom_shrink_targets() -%}
- task: Reconfigure Monitoring services               # Update prometheus targets, push-gateway metrics (optional)
{%- endmacro -%}
```

#### Start

```yaml
scripts:
  - task: Start the cluster                   # Start product specific services
                                              # Start product specific exporters

  {{ admprom_cluster_action_start() }}        # Start Monitoring services
                                              # Prometheus, Grafana, push-gateway (optional), node-exporter
```

`admprom_cluster_action_start` macro do the following:

```yaml
{% macro admprom_cluster_action_start() -%}
  - task: Start Monitoring services           # Prometheus, Grafana, push-gateway (optional), node-exporter

  {{ admprom_start_product_exporters }}       # Start product specific exporters
{%- endmacro -%}
```

#### Stop

```yaml
scripts:
  - task: Stop the cluster                    # Stop product specific services
                                              # Stop product specific exporters

  {{ admprom_cluster_action_stop() }}         # Stop Monitoring services
                                              # Prometheus, Grafana, push-gateway (optional), node-exporter
```

`admprom_cluster_action_stop` macro do the following:

```yaml
{% macro admprom_cluster_action_stop() -%}
  - task: Stop Monitoring services            # Prometheus, Grafana, push-gateway (optional), node-exporter

  {{ admprom_stop_product_exporters }}        # Stop product specific exporters
{%- endmacro -%}
```

### Monitoring (ADMProm) service actions

#### Install\Reinstall

```yaml
scripts:
  - task: Install Monitoring services         # Prometheus, Grafana, push-gateway (optional), node-exporter
                                              # node-exporter is installed on every host of the cluster

  {{ admprom_install_product_exporters }}     # Install product-specific exporters
  {{ admprom_post_service_install }}          # Product-specific actions. For example, update of the cluster's exports
```

#### Uninstall

```yaml
scripts:
  - task: Uninstall Monitoring services       # Prometheus, Grafana, push-gateway (optional), node-exporter
                                              # node-exporter is installed on every host of the cluster

  {{ admprom_uninstall_product_exporters }}   # Uninstall product-specific exporters
  {{ admprom_post_service_uninstall }}        # Product-specific actions. For example, update of the cluster's exports
```

#### Check

```yaml
scripts:
  - task: Check Monitoring services           # Prometheus, Grafana, push-gateway (optional), node-exporter

  {{ admprom_check_product_exporters }}       # Check product-specific exporters
```

#### Reconfigure & Restart

```yaml
scripts:
  - task: Reconfigure Monitoring services     # Prometheus, Grafana, push-gateway (optional), node-exporter

  {{ admprom_reconfigure_product_exporters }} # Reconfigure product-specific exporters
                                              #   - Update configuration
                                              #   - Optional restart of exporters

  {{ admprom_post_service_reconfigure }}      # Product-specific actions. For example, update of the cluster's exports

{{ admprom_service_reconfigure_settings() }}  # Reconfigure & Restart action options:
                                              #   - Toggles to restart product-specific exporters.
```

#### Start

```yaml
scripts:
  - task: Start Monitoring services           # Prometheus, Grafana, node-exporter, push-gateway

  {{ admprom_start_product_exporters }}       # Start product-specific exporters
```

#### Stop

```yaml
scripts:
  - task: Stop Monitoring services            # Prometheus, Grafana, node-exporter, push-gateway

  {{ admprom_stop_product_exporters }}        # Start product-specific exporters
```

#### Add/Remove components

```yaml
scripts:
  - task: Add/Remove components               # Change hc-map with service's component

  {{ admprom_product_specific_change_hc_acl() }}
```

```yaml
{% macro admprom_product_specific_change_hc_acl() -%}
- component: product_exporter_component       # If you want to allow to add this component with the action
  action: add
- component: product_exporter_component       # If you want to allow to remove this component with the action
  action: remove
{%- endmacro -%}
```

Ansible playbooks have to be introduced in `config` section of product-specific exporter's component with `{{ admprom_product_specific_components() }}` macro in the following way:

```yaml
product_exporter_component:
  ...
  config:
    - name: ansible_playbook
      type: string
      default: admprom/components/product_exporter_component.yaml
      read_only: any
      ui_options:
        invisible: True
```

Ansible playbook is running with the following parameters:

- Adding

```yaml
params:
  hosts: prometheus_monitoring.{{ component }}.add
  actions:
    - precheck
    - install
    - check
```

- Removing

```yaml
params:
  hosts: prometheus_monitoring.{{ component }}.remove
  actions:
    - uninstall
```

## Monitoring service's configuration customization

Monitoring service configuration has custom section filled with macro `admprom_product_specific_settings`:

```yaml
config:
  {{ admprom_product_specific_settings() }}
```

This section could include product-specific exporter's settings like ports, `/metrics` endpoints, etc. Below is an example of such a macro from the ADQM bundle:

```yaml
{% macro product_specific_settings() -%}
- name: bundle_services_settings
  display_name: ADQM's services metric settings
  type: group
  subs:
    - name: clickhouse_listen_port
      type: integer
      display_name: "Clickhouse listen port"
      default: 9363
      description: "Clickhouse metrics service listen on"
      required: True
    - name: clickhouse_endpoint
      type: string
      display_name: "Clickhouse endpoint"
      default: "/metrics"
      description: "Clickhouse metrics service endpoint to retrieve metrics"
      required: True
    - name: zookeeper_listen_port
      type: integer
      display_name: "Zookeeper listen port"
      default: 9020
      description: "Zookeeper metrics service listen on"
      required: True
    - name: chkeeper_listen_port
      type: integer
      display_name: "Clickhouse Keeper listen port"
      default: 9010
      description: "CHKeeper(standalone) listen port for Clickhouse Keeper endpoint"
      required: True
    - name: chkeeper_endpoint
      type: string
      display_name: "Clickhouse Keeper endpoint"
      default: "/metrics"
      description: "CHKeeper(standalone) metrics endpoint"
      required: True
{%- endmacro -%}
```

### Prometheus targets

Monitoring service manages `node-exporter` and `push-gateway` targets by itself in the prometheus's configuration files. Targets for product-specific exporters are rendered with `admprom/prometheus/config.yml.j2` file which have to be located in the product bundles' source code.

Below is an example of this file from the ADQM bundle:

```yaml
{% if groups['adqmdb.chserver'] is defined %}
{% set clickhouse_listen_port = services.prometheus_monitoring.config.bundle_services_settings.clickhouse_listen_port | string %}
  - job_name: job-clickhouse
    metrics_path: '{{ services.prometheus_monitoring.config.bundle_services_settings.clickhouse_endpoint }}'
    static_configs:
      - targets: [{% for host in groups['adqmdb.chserver'] %}"{{ hostvars[host]['ansible_fqdn'] }}:{{ clickhouse_listen_port }}"{% if not loop.last %},{% endif %}{% endfor %}]
        labels:
          cluster_name: "{{ cluster.name }}"
          cluster_id: "{{ cluster.config.cluster_uuid }}"
{% endif %}

{% if groups['chproxy.server'] is defined %}
{% set chproxy_listen_port = services.chproxy.config.network_conf.http_listen_port | string %}
  - job_name: job-chproxy
    metrics_path: '/metrics'
    static_configs:
      - targets: [{% for host in groups['chproxy.server'] %}"{{ hostvars[host]['ansible_fqdn'] }}:{{ chproxy_listen_port }}"{% if not loop.last %},{% endif %}{% endfor %}]
        labels:
          cluster_name: "{{ cluster.name }}"
          cluster_id: "{{ cluster.config.cluster_uuid }}"
{% endif %}

{% if groups['zookeeper.SERVER'] is defined %}
{% set zookeeper_listen_port = services.prometheus_monitoring.config.bundle_services_settings.zookeeper_listen_port | string %}
  - job_name: job-zookeeper
    static_configs:
      - targets: [{% for host in groups['zookeeper.SERVER'] %}"{{ hostvars[host]['ansible_fqdn'] }}:{{ zookeeper_listen_port }}"{% if not loop.last %},{% endif %}{% endfor %}]
        labels:
          cluster_name: "{{ cluster.name }}"
          cluster_id: "{{ cluster.config.cluster_uuid }}"
{% endif %}

{% if groups['chkeeper.server'] is defined %}
{% set chkeeper_listen_port = services.prometheus_monitoring.config.bundle_services_settings.chkeeper_listen_port | string %}
  - job_name: job-chkeeper
    metrics_path: '{{ services.prometheus_monitoring.config.bundle_services_settings.chkeeper_endpoint }}'
    static_configs:
      - targets: [{% for host in groups['chkeeper.server'] %}"{{ hostvars[host]['ansible_fqdn'] }}:{{ chkeeper_listen_port }}"{% if not loop.last %},{% endif %}{% endfor %}]
        labels:
          cluster_name: "{{ cluster.name }}"
          cluster_id: "{{ cluster.config.cluster_uuid }}"
{% endif %}
```

### Grafana dashboards

Monitoring service exports product-specific dashboards during Grafana installation. Dashboards are located in `admprom/grafana/dashboards/` directory and have to have extension `*.j2`.
