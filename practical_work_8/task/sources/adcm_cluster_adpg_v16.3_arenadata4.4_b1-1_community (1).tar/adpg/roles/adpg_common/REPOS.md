"https://downloads.adsw.io/ADPG-CORE/16.3_arenadata4/metadata.yaml"
