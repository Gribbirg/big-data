#!/usr/bin/python

# Copyright: (c) Arenadata Software LLC, 2022
# www.arenadata.tech
# Written by Pavel Prokopov <ppa@arenadata.io>


"""
Ansible module for check package in debian, astralinux
"""


import os
import re

from ansible.module_utils.basic import AnsibleModule

ANSIBLE_METADATA = {
    'metadata_version': '1.1',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = '''
---
module: deb_pkg_check

short_description: Ansible module for check package in astralinux

version_added: "2.4"

description:
    - "Ansible module for check package in debian, astralinux"

options:
    pkg:
        description:
            - format: <pkg_name>[=<pkg_version>[-<pkg_build>]]
        required: true
        type; string
        aliases:
            - name
            - package
    check:
        description:
            - kind of check
        choices:
            - available
            - installed
        type: string
        required: true
        aliases: test

    update_cache:
        description:
            - update apt cache
            - only for check available
        type: bool
        default: false
        aliases: update-cache
    clean_cache:
        description:
            - clean apt cache
            - only for check available
        type: bool
        default: false
        aliases: clean-cache
    dir_etc:
        description:
            - options for apt-cache: -o dir::etc=
            - only for check available
        type: string
        required: false
        aliases: etc
    dir_cache
        description:
            - options for apt-cache: -o dir::cache=
            - only for check available
        type: string
        required: false
        aliases: cache

author:
    - Pavel Prokopov (ppa@arenadata.io)
'''

EXAMPLES = '''
# Test availability
- name: Test1 availability
  deb_pkg_check:
    pkg: '{{ item }}'
    check: 'available'
    update-cache: yes
    clean-cache: yes
    dir_etc: "/tmp/.private/root/ansible.GI1E1v/apt"
    dir_cache: "/tmp/.private/root/ansible.5EZsaz"
    loop:
      - 'sigar=1.6.5-41'
      - 'sigar=1.6.5'
      - 'sigar'
- name: Test2 availability
  deb_pkg_check:
    pkg: 'tar'
    check: 'available'

# Test installed
- name: Test1 installed
  deb_pkg_check:
      pkg: '{{ item }}'
      check: 'installed'
    loop:
      - 'sigar=1.6.5-41'
      - 'sigar=1.6.5'
      - 'sigar'

'''

RETURN = '''
# Test installed good
installed: true
versions: {
    "build": "42",
    "version": "1.6.5"
}
# Test installed bad
installed: false
versions: null

# Test availability good
available: true
versions: [
    {
        "build": "42",
        "version": "1.6.5"
    },
    {
        "build": "41",
        "version": "1.6.5"
    }
]
# Test availability bad
available: false
versions: null
'''


APT_CACHE = '/usr/bin/apt-cache'
APT_GET = '/usr/bin/apt-get'
DPKGQUERY = '/usr/bin/dpkg-query'


class PkgCheck(AnsibleModule):
    '''
    Class for check packages in altlinux
    '''

    def __init__(self):
        self.result = dict(
            changed=False
        )

        modules_args = dict(
            pkg=dict(type='str', required=True, aliases=['name', 'package']),
            update_cache=dict(type='bool', default=False, aliases=['update-cache']),
            clean_cache=dict(type='bool', default=False, aliases=['clean-cache']),
            check=dict(type='str', required=True, aliases=['test'],
                       choices=['available', 'installed']),
            dir_etc=dict(type='str', required=False, aliases=['etc']),
            dir_cache=dict(type='str', required=False, aliases=['cache'])
        )

        super(PkgCheck, self).__init__(argument_spec=modules_args, supports_check_mode=False)

        for path in [APT_CACHE, APT_GET, DPKGQUERY]:
            if not os.path.exists(path):
                self.fail_json(msg='cannot find %s' % path)

        for opt_dir in ['dir_etc', 'dir_cache']:
            if self.params[opt_dir]:
                if self.params['check'] != 'available':
                    self.fail_json(msg='bad option: %s' % opt_dir, **self.result)
                if not os.path.isdir(self.params[opt_dir]):
                    self.fail_json(msg='%s is not dir: %s'
                                   % (opt_dir, self.params[opt_dir]),
                                   **self.result)

    def update_package_db(self):
        '''
        apt-get update
        '''

        opt = ""
        if self.params['dir_etc']:
            opt = opt + " -o dir::etc=" + self.params['dir_etc']
        if self.params['dir_cache']:
            opt = opt + " -o dir::cache=" + self.params['dir_cache']
        cmd = "%s %s update" % (APT_GET, opt)
        ret, out, err = self.run_command(cmd)

        error = dict(
            cmd=cmd,
            rc=ret,
            stderr=err,
            stdout=out
        )

        if ret != 0:
            self.fail_json(msg="could not update package db", **error)

    def clean_apt_cache(self):
        '''
        apt-get clean
        '''

        opt = ""
        if self.params['dir_etc']:
            opt = opt + " -o dir::etc=" + self.params['dir_etc']
        if self.params['dir_cache']:
            opt = opt + " -o dir::cache=" + self.params['dir_cache']
        cmd = "%s %s clean" % (APT_GET, opt)

        ret, out, err = self.run_command(cmd)

        error = dict(
            cmd=cmd,
            rc=ret,
            stderr=err,
            stdout=out
        )

        if ret != 0:
            self.fail_json(msg="could not clean apt cache", **error)

    def parse_pkg(self):
        '''
        parse string package name
        '''

        pkg = self.params['pkg']
        # pkg: '<name>[[=<version>]-<build]'
        # https://regex101.com/r/iQqhkO/1
        match = re.match(r"^(?P<name>[^=]+)(=(?P<version>.*(?=-)|(?:.*))(-(?P<build>.*))?)?$", pkg)
        if match is None:
            self.fail_json(msg="Bad format of pkg: '%s'" % pkg, **self.result)
        return match.groupdict("")

    def get_installed_versions(self, pkg_name):
        '''
        get installed package version
        '''

        cmd = "%s --show --showformat='${Package} = ${Version}\n' %s" % (DPKGQUERY, pkg_name)
        ret, out, err = self.run_command(cmd)

        # print(out) ###

        match = re.match(
            r".*" + re.escape(pkg_name) + r" = (?P<version>.*(?=-)|(?:.*))(-(?P<build>.*))?$",
            out)
        if match is None:
            error = dict(
                cmd=cmd,
                rc=ret,
                stderr=err,
                stdout=out
            )
            self.result['error'] = error
            return None

        versions = []
        versions.append(match.groupdict(""))

        return versions

    def get_available_versions(self, pkg_name):
        '''
        get available package versions
        '''

        opt = ""
        if self.params['dir_etc']:
            opt = opt + " -o dir::etc=" + self.params['dir_etc']
        if self.params['dir_cache']:
            opt = opt + " -o dir::cache=" + self.params['dir_cache']
        cmd = "%s %s show %s" % (APT_CACHE, opt, pkg_name)
        ret, out, err = self.run_command(cmd)

        if ret != 0:
            error = dict(
                cmd=cmd,
                rc=ret,
                stderr=err,
                stdout=out
            )
            self.result['error'] = error
            return None

        versions = []
        # https://regex101.com/r/Xzx25Q/1
        for match in re.finditer(r'^Version: (?P<version>.*(?=-)|(?:.*))(-(?P<build>.*))?$', out, flags=re.M):
            if match is not None:
                versions.append(match.groupdict(""))

        return versions

    def check_pkg(self, check):
        '''
        check package
        '''

        def ret_status(status):
            self.result[check] = status
            self.exit_json(**self.result)

        pkg = self.parse_pkg()

        if check == "available":
            versions = self.get_available_versions(pkg['name'])
        elif check == "installed":
            versions = self.get_installed_versions(pkg['name'])

        self.result['versions'] = versions

        if versions is None:
            ret_status(False)

        if len(versions) > 0 and (pkg['version'] is None or pkg['version'] == ""):
            ret_status(True)

        for ver in versions:
            if pkg['version'] == ver['version']:
                if pkg['build'] is None or pkg['build'] == "" or pkg['build'] == ver['build']:
                    ret_status(True)

        ret_status(False)

    def run(self):
        '''
        run
        '''

        if self.params['update_cache']:
            if self.params['check'] != 'available':
                self.fail_json(msg='bad option update_cache for check available',
                               **self.result)
            self.update_package_db()

        if self.params['clean_cache']:
            if self.params['check'] != 'available':
                self.fail_json(msg='bad option clean_cache for check available',
                               **self.result)
            self.clean_apt_cache()

        self.check_pkg(self.params['check'])


def main():
    """
    Main function that run run_module()
    """

    PkgCheck().run()


if __name__ == '__main__':
    main()
