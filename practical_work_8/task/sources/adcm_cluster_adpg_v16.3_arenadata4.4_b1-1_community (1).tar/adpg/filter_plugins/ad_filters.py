"""
Arenadata filter_plugins
for example https://github.com/ansible/ansible/blob/devel/lib/ansible/plugins/filter/core.py
"""

import os
from functools import partial

from ansible.utils.unicode import unicode_wrap


# pylint: disable=no-self-use, too-few-public-methods
class FilterModule:
    """Arenadata jinja2 filter plugins"""
    def filters(self):
        """filter plugins name with functions"""
        return {
            'normpath': partial(unicode_wrap, os.path.normpath)
        }
