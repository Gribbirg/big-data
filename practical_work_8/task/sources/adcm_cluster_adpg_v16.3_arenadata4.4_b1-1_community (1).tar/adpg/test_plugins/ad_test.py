"""
Arenadata test_plugins
for example https://github.com/ansible/ansible/blob/devel/lib/ansible/plugins/test/core.py
"""


def intersect(list_a, list_b):
    """Check if to list like objects has intersection"""
    return bool(set(list_a) & set(list_b))


class TestModule:
    """Arenadata jinja2 test plugins"""

    def tests(self):
        """Map test plugins name with functions"""
        return {
            'intersect': intersect,
        }
