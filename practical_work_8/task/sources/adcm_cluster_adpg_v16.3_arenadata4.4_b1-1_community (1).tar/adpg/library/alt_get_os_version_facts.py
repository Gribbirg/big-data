#!/usr/bin/python

# Copyright: (c) Arenadata Software LLC, 2021
# www.arenadata.tech
# Written by Pavel Prokopov <ppa@arenadata.io>


"""
Ansible module for getting version of altlinux
"""


import os
from ansible.module_utils.basic import AnsibleModule


ANSIBLE_METADATA = {
    'metadata_version': '1.1',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = '''
---
module: alt_get_os_version_facts

short_description: Ansible module for getting version of altlinux

version_added: "1.0"

description:
    - "Ansible module for getting version of altlinux"

author:
    - Pavel Prokopov (ppa@arenadata.io)
'''

EXAMPLES = '''
- hosts: CLUSTER
  gather_facts: true
  tasks:
    - name: Get os-version from Altlinux
      alt_get_os_version_facts:
      when: ansible_os_family | lower == "altlinux"
    - name: debug
      debug:
        msg: "{{ ansible_facts }}"
'''

RETURN = '''
TASK [debug] *******************************************************************
ok: [ppa-alt1.d.y.adsw.io] =>
  msg:
    _facts_gathered: true
    ...
    altlinux_branding:
      is_exist: true
      os-release:
        ANSI_COLOR: '"1;33"'
        BUG_REPORT_URL: '"https://bugs.altlinux.org/"'
        CPE_NAME: '"cpe:/o:alt:spserver:8.2"'
        HOME_URL: '"https://basealt.ru/"'
        ID: altlinux
        NAME: '"ALT SPServer"'
        PRETTY_NAME: '"ALT 8 SP Server (cliff)"'
        VERSION: '"8.2"'
        VERSION_ID: '8.2'
    ...
'''


ALTLINUX_BRANDING_FILE = "/usr/share/branding-data-current/release/os-release"


def main():
    """Get real altlinux version"""

    module_args = {}

    result = dict(
        changed=False,
        ansible_facts={'altlinux_branding': {}}
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    if module.check_mode:
        module.exit_json(**result)

    branding_file_exists = os.path.isfile(ALTLINUX_BRANDING_FILE)

    result['ansible_facts']['altlinux_branding']['is_exist'] = branding_file_exists

    if branding_file_exists:
        with open(ALTLINUX_BRANDING_FILE) as file:
            file_contents = file.read()

        file_contents = file_contents.replace('"', '')
        file_contents = file_contents.replace('\'', '')

        result['ansible_facts']['altlinux_branding']['os_release'] = \
            (lambda str: dict(x.split("=") for x in str.splitlines()))(file_contents)

    module.exit_json(**result)


if __name__ == '__main__':
    main()
