#!/usr/bin/python

"""
Ansible module for testing ntp server availabiliy
"""

import socket
import struct
import time

from ansible.module_utils.basic import AnsibleModule

ANSIBLE_METADATA = {
    'metadata_version': '1.1',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = '''
---
module: ntp_ping

short_description: Module for testing ntp server availabiliy

version_added: "2.4"

description:
    - "Module for testing ntp server availabiliy"

options:
    host:
        description:
            - NTP server host for testing
        required: true

author:
    - Vasiliy Ivanov (ivi@arenadata.io)
'''

EXAMPLES = '''
# Test NTP server availability
- name: Test NTP server
  ntp_ping:
    host: 0.ru.pool.ntp.org
'''

RETURN = ''''''


def run_module():
    """
    Function is send test request to remote NTP server and try parse response
    :rtype: object
    """
    # define available arguments/parameters a user can pass to the module
    module_args = dict(
        host=dict(type='str', required=True)
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # change is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task
    result = dict(
        changed=False
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # manipulate or modify the state as needed (this is going to be the
    # part where your module will do what it needs to do)
    # NTP query msg: protocol version 3, host type - 3 - client
    msg = '\x1b' + 47 * '\0'
    client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    client.settimeout(15.0)
    try:
        client.sendto(msg.encode(), (module.params['host'], 123))
        msg, _ = client.recvfrom(1024)
        seconds = struct.unpack("!12I", msg)[10]
        seconds -= 2208988800
        time.ctime(seconds).replace("  ", " ")
    except socket.timeout:
        module.fail_json(msg="Request timeout!")
    except socket.gaierror:
        module.fail_json(msg="Hostname not resolved!")
    else:
        pass
        # result['original_message'] = module.params['name']
        # result['message'] = 'goodbye'

    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result
    # if module.params['name'] == 'fail me':
    #     module.fail_json(msg='You requested this to fail', **result)

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)


def main():
    """
    Main function that run run_module()
    """
    run_module()


if __name__ == '__main__':
    main()
